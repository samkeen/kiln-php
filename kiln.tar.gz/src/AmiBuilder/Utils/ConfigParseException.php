<?php

namespace Io\Samk\AmiBuilder\Utils;


class ConfigParseException extends \Exception
{

}